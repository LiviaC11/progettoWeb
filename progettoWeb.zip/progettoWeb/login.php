<?php
require_once 'bootstrap.php';

$templateParams["titolo"] = "CoHappy - Login";
//$templateParams["nome"] = "login_template.php";

require 'template/base.php';
?>