<?php 
require_once 'bootstrap.php';

// Parametri della pagina
$templateParams["titolo"] = "CoHappy - Contatti";
$templateParams["nome"] = "template/contatti_template.php"; 

require 'template/base.php';
?>