<?php
require_once 'bootstrap.php';

$templateParams["titolo"] = "CoHappy - Home";
$templateParams["nome"] = "home.php";

require 'template/base.php';
?>